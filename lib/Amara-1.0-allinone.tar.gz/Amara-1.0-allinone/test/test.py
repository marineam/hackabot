#!/usr/bin/env python
__revision__ = '$Id: test.py,v 1.8 2004/10/28 14:46:50 jkloth Exp $'

#import warnings
#warnings.filterwarnings('ignore')

from Ft.Lib.TestSuite import Test
Test(name='4Suite',
     packages=['Lib',
               'Xml',
               'Rdf',
               'Server',
               #'Ods',
               ]
     )
