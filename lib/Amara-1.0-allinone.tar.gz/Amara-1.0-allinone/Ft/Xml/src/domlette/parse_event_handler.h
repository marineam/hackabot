#ifndef DOMLETTE_PARSE_EVENT_HANDLER_H
#define DOMLETTE_PARSE_EVENT_HANDLER_H

#ifdef __cplusplus
extern "C" {
#endif

#include "Python.h"

  PyObject *ParseDocument(PyObject *inputSource, int readDtd, int asEntity);

  int DomletteBuilder_Init(PyObject *module);
  void DomletteBuilder_Fini(void);
  
#ifdef __cplusplus
}
#endif

#endif /* DOMLETTE_PARSE_EVENT_HANDLER_H */

