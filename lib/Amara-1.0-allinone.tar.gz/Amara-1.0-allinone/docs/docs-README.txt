########################################################################
# $Header: /var/local/cvsroot/4Suite/docs/docs-README.txt,v 1.2 2003/06/08 02:07:57 mbrown Exp $

This is the README for the docs directory.
There is not much in this directory for end users.

Static documentation files in the xml subdirectory are transformed
into both plain text and HTML formats automatically during
installation. This documentation is placed in
{python/site-packages}/Ft/Share/Docs.

API documentation is generated automatically in both XML and HTML
formats during installation. This documentation is also placed in
{python/site-packages}/Ft/Share/Docs.

Pregenerated docs may also be downloaded and installed separately,
or browsed on the web at http://4suite.org/

What's here:

docs-README.txt   This file
ftdocs.py         Support file for documentation autogeneration
mkpaths.py        Support file for documentation autogeneration
paths.xsl         Support file for documentation autogeneration
xml/              Static documentation in XML formats (e.g. DocBook XML)

__packageinfo__.py files in the major module directories also
contain info that supports autogeneration of documentation.
