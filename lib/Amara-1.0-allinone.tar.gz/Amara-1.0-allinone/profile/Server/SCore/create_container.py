import sys, os
p = os.path.join("..","..")
sys.path.append(p)
import profile_util


def do_create():

    repo = profile_util.GetRepo()
    repo.createContainer('/profile/cont')
    repo.txCommit()

   


def do_profile():

    #Init
    repo = profile_util.GetRepo()
    if repo.hasResource('/profile'):
        repo.deleteResource('/profile')
    repo.createContainer('/profile',1)
    repo.txCommit()

    profile_util.run("do_create()",globals(),locals())




if __name__ == '__main__':
    profile_util.InitRepo()
    do_profile()

