import sys, os
p = os.path.join("..","..")
sys.path.append(p)
import profile_util

def do_fetch():
    repo = profile_util.GetRepo()
    repo.fetchResource('/profile/cont')
    repo.txRollback()



def do_profile():

    #Init
    repo = profile_util.GetRepo()
    if repo.hasResource('/profile'):
        repo.deleteResource('/profile')
    repo.createContainer('/profile/cont',1)
    repo.txCommit()

    profile_util.run("do_fetch()",globals(),locals())




if __name__ == '__main__':
    profile_util.InitRepo()
    do_profile()

