
import sys, os
p = os.path.join("..")
sys.path.append(p)
import profile_util
from Ft.Rdf import Model
from Ft.Rdf import Statement

NUM_STATEMENT = 10000

REDUNDANT_FACTOR=10
BLOCK_SIZE = 500
        


def do_add(db):

    m = Model.Model(db)

    for ctr in range(NUM_STATEMENT):
        stmt = Statement.Statement('sub%d'%ctr,
                                   'pred%d'%ctr,
                                   'obj%d'%ctr,
                                   'uri%d'%ctr)
        m.add([stmt])
    db.commit()


def do_profile():
    db = profile_util.GetRdfDriver()
    profile_util.run("do_add(db)",globals(),locals())


if __name__ == '__main__':
    profile_util.InitModel()
    do_profile()


