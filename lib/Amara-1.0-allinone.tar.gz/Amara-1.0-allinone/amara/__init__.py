#Module amara
__version__ = '1.0'
